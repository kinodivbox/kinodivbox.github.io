(function () {
  'use strict';

  function extractId(url) {
    const match = url.match(/\/(film|series)\/(\d+)/);
    return match ? match[2] : null;
  }

  function createButton(id) {
    const existing = document.querySelector('.kinoDivBox');
    if (existing) return;

    const btn = document.createElement('button');
    btn.textContent = 'Смотреть на KinoDivBox';
    btn.className = 'kinoDivBox';
    btn.style.cssText = `
      margin-top: 8px;
      padding: 10px 15px;
      background-color: #ff6c00;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
    `;
    btn.addEventListener('click', () => {
      window.open(`https://kinodivbox.github.io/ID.html?id=${id}`, '_blank');
    });

    return btn;
  }

  function insertButton() {
    const id = extractId(location.href);
    if (!id) return;

    const container = document.querySelector('[data-tid="bbf5d5a"]') ||
                      document.querySelector('[class*="buttons"]') ||
                      document.querySelector('[class*="styles_buttons"]');

    if (container && !document.querySelector('.kinoDivBox')) {
      const btn = createButton(id);
      if (btn) container.appendChild(btn);
    }
  }

  let lastUrl = '';
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(insertButton, 1000);
    }
  }, 500);

  setTimeout(insertButton, 1500);
})();